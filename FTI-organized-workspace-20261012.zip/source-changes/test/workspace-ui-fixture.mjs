// Local QA only. Never contacts public RPC or imports production users/keys.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import ganache from 'ganache';
import {JsonRpcProvider,Wallet,parseEther,MaxUint256} from 'ethers';
import {verifyV3Deployment} from '../scripts/continuity-release.mjs';
import {startWeb} from '../scripts/server.mjs';
const engine=ganache.server({chain:{chainId:31337,time:new Date('2026-10-12T15:00:00Z')},logging:{quiet:true},wallet:{totalAccounts:12},miner:{timestampIncrement:1,blockGasLimit:30000000}});
await engine.listen(0,'127.0.0.1');
const rpc='http://127.0.0.1:'+engine.address().port;
const p=new JsonRpcProvider(rpc,undefined,{cacheTimeout:-1});p.pollingInterval=30;
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'fti-workspace-browser-'));
const keys=Object.values(engine.provider.getInitialAccounts()).map(v=>v.secretKey);
const accounts=keys.map(k=>new Wallet(k).address);
const dao=path.join(dir,'dao.json'),output=path.join(dir,'deployment.json');
fs.writeFileSync(dao,JSON.stringify({threshold:5,partners:accounts.slice(1,8)}),{mode:0o600});
let log='';
const exit=await new Promise((resolve,reject)=>{
 const child=spawn(process.execPath,['scripts/deploy-continuity-testnet.mjs'],{env:{...process.env,RPC_URL:rpc,DEPLOYER_PRIVATE_KEY:keys[0],DAO_CONFIG:dao,V3_TESTNET_SECRETS:path.join(dir,'helpers.json'),V3_DEPLOYMENT_FILE:output}});
 child.stdout.on('data',d=>log+=d);child.stderr.on('data',d=>log+=d);child.on('error',reject);child.on('exit',resolve);
});
if(exit!==0){console.error(log);throw Error('Local QA deployment failed');}
const cfg=JSON.parse(fs.readFileSync(output));
const c=await verifyV3Deployment(cfg,p),signer=await p.getSigner(accounts[0]);
const send=async x=>{const r=await (await x).wait();if(r.status!==1)throw Error('QA transaction failed');};
await send(c.usd.connect(signer).faucet());
await send(c.usd.connect(signer).approve(c.binary.target,MaxUint256));
await send(c.binary.connect(signer).addUnits(2));
await send(c.usd.connect(signer).approve(c.token.target,MaxUint256));
for(const amount of ['100','20','15','10'])await send(c.token.connect(signer).buy(parseEther(amount),0,MaxUint256));
// Add only local unlocked accounts to the existing local-mode selector.
cfg.accounts=accounts;fs.writeFileSync(output,JSON.stringify(cfg),{mode:0o600});
process.env.RPC_URL=rpc;process.env.PORT='0';
const web=await startWeb(output);
console.log('FTI_QA_READY '+JSON.stringify({scope:'LOCAL_ONLY',url:'http://127.0.0.1:'+web.address().port,rpc,accounts:accounts.slice(0,2)}));
let stopped=false;
async function stop(){if(stopped)return;stopped=true;web.close();p.destroy();await engine.close();fs.rmSync(dir,{recursive:true,force:true});process.exit(0);}
process.on('SIGTERM',stop);process.on('SIGINT',stop);
