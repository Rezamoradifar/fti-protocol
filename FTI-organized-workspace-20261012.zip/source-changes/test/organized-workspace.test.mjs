import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {LANGUAGES,languageFrom} from '../frontend/language-policy.js';
import {parseWorkspaceRoute,routeHash,visibleWorkspaceSections,TRADE_SIDES} from '../frontend/workspace-navigation.js';
import {sharedWebsite,shareLinks} from '../frontend/social-share.js';
import {curveGeometry} from '../frontend/spot-history.js';
const read=p=>fs.readFileSync(new URL('../'+p,import.meta.url),'utf8');

test('Persian is last without changing the default or RTL semantics',()=>{
 assert.equal(LANGUAGES.at(-1).code,'fa');assert.equal(LANGUAGES[0].code,'en');
 assert.equal(languageFrom('https://ftiprotocol.com/',null),'fa');
 assert.deepEqual(LANGUAGES.filter(l=>l.dir==='rtl').map(l=>l.code).sort(),['ar','fa']);
});
test('one connection entry point; shortcuts never proxy wallet-connect clicks',()=>{
 const source=read('frontend/main.jsx');assert.equal((source.match(/id="connect"/g)||[]).length,1);
 assert.doesNotMatch(source,/getElementById\(['"]connect['"]\).*click\(/);
 assert.doesNotMatch(source,/className="priority-actions"/);
 assert.match(source,/function QuickActions/);
});
test('all financial forms keep one unique ID and required transaction guards',()=>{
 const source=read('frontend/main.jsx');
 for(const id of ['buy-form','sell-form','transfer-form','auto-form','register-form'])assert.equal((source.match(new RegExp('id="'+id+'"','g'))||[]).length,1,id);
 const ids=[...source.matchAll(/\bid="([^"{}]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);
 assert.match(source,/data-write disabled data-requires="buyer"/);assert.match(source,/data-write disabled data-requires="unlocked"/);
});
test('home shows four real sections in workflow order; other pages remain focused',()=>{
 assert.deepEqual(visibleWorkspaceSections('member','overview'),['overview','trade','rewards','network']);
 assert.deepEqual(visibleWorkspaceSections('member','trade'),['trade']);
 assert.deepEqual(visibleWorkspaceSections('admin','admin'),['admin']);
 assert.match(read('frontend/main.jsx'),/<Overview\/><Trading\/><EmergencyExit\/><Rewards\/><Membership\/>/);
});
for(const [hash,expected] of [
 ['#overview',{page:'overview',jump:null,trade:null}],
 ['#overview/trade/transfer',{page:'overview',jump:'trade',trade:'transfer'}],
 ['#overview/auto-preferences',{page:'overview',jump:'auto-preferences',trade:null}],
 ['#trade/sell',{page:'trade',jump:null,trade:'sell'}],
 ['#transfer',{page:'trade',jump:null,trade:'transfer'}],
 ['#<script>',{page:'overview',jump:null,trade:null}],
 ['#overview/missing',{page:'overview',jump:null,trade:null}],
])test('bounded route parser: '+hash,()=>assert.deepEqual(parseWorkspaceRoute(hash),expected));
test('route roundtrip keeps local trade modes and does not accept external destinations',()=>{
 for(const mode of TRADE_SIDES){assert.equal(parseWorkspaceRoute(routeHash({page:'trade',trade:mode})).trade,mode);assert.equal(parseWorkspaceRoute(routeHash({page:'overview',jump:'trade',trade:mode})).trade,mode);}
 assert.throws(()=>routeHash({page:'https://evil.example/'}));
});
test('exchange uses three labelled, keyboard-operable, mounted panels',()=>{
 const src=read('frontend/trade-center.jsx');
 assert.match(src,/role="tablist"/);assert.match(src,/role="tab"/);assert.match(src,/role="tabpanel"/);
 assert.match(src,/aria-controls/);assert.match(src,/aria-labelledby/);assert.match(src,/hidden=\{side!==mode\}/);
 for(const key of ['Home','End','ArrowLeft','ArrowRight'])assert(src.includes("'"+key+"'"));
 assert.doesNotMatch(src,/sendTransaction|\.approve\(|requestAccounts|\.submit\(/);
});
test('members can trade on their own surface without switching to token domain',()=>{
 const src=read('frontend/surfaces.js');assert.match(src,/member:\[\['overview','Home'\],\['trade','Trade center'\]/);
 assert.match(src,/page==='trade'&&surface==='member'/);
});
test('Telegram and X are explicit sharing drafts, not invented official channels',()=>{
 for(const lang of LANGUAGES.map(x=>x.code)){
  const rows=shareLinks(lang);assert.equal(rows.length,2);
  for(const row of rows){const url=new URL(row.href);assert.equal(url.protocol,'https:');assert.equal(url.searchParams.get('url'),sharedWebsite(lang));}
  assert.equal(new URL(rows[0].href).pathname,'/share/url');assert.equal(new URL(rows[1].href).pathname,'/intent/tweet');
 }
 assert.equal(new URL(sharedWebsite('javascript:alert(1)')).search,'');
 assert.match(read('frontend/global-components.jsx'),/Nothing is posted automatically/);
});
test('copy failure offers manual copy without claiming success',()=>{
 const source=read('frontend/global-components.jsx');assert.match(source,/await navigator.clipboard.writeText/);
 assert.match(source,/catch\{setCopyState\('manual'\)/);assert.match(source,/copyState==='manual'&&<input/);
});
test('curve geometry uses cubic segments and never invents observations or overshoots endpoints',()=>{
 const points=[{time:1,price:1},{time:2,price:3},{time:4,price:2}];const g=curveGeometry(points);
 assert.equal(g.xy.length,points.length);assert.equal((g.path.match(/C/g)||[]).length,2);
 for(let i=1;i<g.xy.length;i++){
  const y0=g.xy[i-1][1],y1=g.xy[i][1];
  for(let j=0;j<=100;j++){const t=j/100,y=(1-t)**3*y0+3*(1-t)**2*t*y0+3*(1-t)*t*t*y1+t**3*y1;assert(y>=Math.min(y0,y1)-1e-9&&y<=Math.max(y0,y1)+1e-9);}
 }
 assert.equal(curveGeometry([]),null);assert.equal(curveGeometry([{time:1,price:2}]).path.includes('C'),false);
 assert.match(read('frontend/live-market.js'),/One observation: a curve needs another verified price/);
});
test('navigation can initialise before the controller API resolves',()=>{
 const source=read('frontend/main.jsx');assert(source.indexOf('const dispose=initWorkspaceNavigation')<source.indexOf("import('./controller.js')"));
 assert.doesNotMatch(read('frontend/controller.js'),/\bnavigate\(/);
});
test('old financial contracts are byte-identical to the reviewed fresh-release base',()=>{
 const expected={'FundedBinaryPlanUpgradeable.sol':'bde68a05b92560ab44a7ba37b75aec80801df799','FTIReserveTokenUpgradeable.sol':'18017b845e023fee13c52a72f0d812b9b167c813'};
 for(const [name,sha] of Object.entries(expected)){
  const bytes=Buffer.from(read('contracts/'+name));const digest=createHash('sha1').update(Buffer.concat([Buffer.from('blob '+bytes.length+'\0'),bytes])).digest('hex');assert.equal(digest,sha);
 }
});
