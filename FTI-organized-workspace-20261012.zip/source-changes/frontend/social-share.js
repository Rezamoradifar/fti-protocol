// No auto-posting and no inferred official account identities. These are explicit
// user-initiated sharing drafts, separate from the approved account links.
const canonical='https://ftiprotocol.com/';
export function sharedWebsite(language='en'){
 const u=new URL(canonical);
 if(['en','ar','tr','zh-CN','ru','es','fa'].includes(language))u.searchParams.set('lang',language);
 return u.href;
}
export function shareLinks(language){
 const value=sharedWebsite(language);
 const telegram=new URL('https://t.me/share/url');telegram.searchParams.set('url',value);
 const x=new URL('https://twitter.com/intent/tweet');x.searchParams.set('url',value);
 return [{id:'telegram',label:'Share on Telegram',href:telegram.href},{id:'x',label:'Share on X',href:x.href}];
}
