import {siteLinks} from './site-links.js';
const sites=siteLinks(location.href);
// Dedicated views share the same deployment and wallet session.
export const surface=location.pathname.startsWith('/admin')?'admin':location.pathname.startsWith('/token')?'token':'member';
export const surfaceTitle={member:'MEMBER WORKSPACE',token:'FTI TOKEN',admin:'PROTOCOL ADMINISTRATION'}[surface];
export const surfacePages={member:[['overview','Home'],['trade','Trade center'],['rewards','Rewards'],['network','Membership'],['activity','Activity']],token:[['token-home','Token overview'],['trade','Trade center'],['activity','Activity']],admin:[['admin','Management'],['activity','Activity']]}[surface];
export const defaultPage=surfacePages[0][0];
export function pagePath(page){if(page==='trade'&&surface==='member')return sites.member+'#trade';if(['trade','token-home'].includes(page))return sites.trade.split('#')[0]+'#'+page;if(page==='admin')return sites.council;return sites.member+'#'+page;}
