// Presentation navigation only. Mounted forms, wallet state and transaction handlers
// are retained; navigation must never initiate an approval, connection or payment.
export const TRADE_SIDES=Object.freeze(['buy','sell','transfer']);
export const HOME_SECTIONS=Object.freeze(['overview','trade','rewards','network']);
const pageNames=new Set(['overview','trade','rewards','network','activity','token-home','admin']);
const homeTargets=new Set(['trade','rewards','network','auto-preferences']);
export function parseWorkspaceRoute(hash,defaultPage='overview'){
 const [first,second,third]=String(hash||'').replace(/^#/,'').split('/');
 if(TRADE_SIDES.includes(first))return {page:'trade',jump:null,trade:first};
 const page=pageNames.has(first)?first:defaultPage;
 const jump=page==='overview'&&homeTargets.has(second)?second:null;
 const trade=page==='trade'?(TRADE_SIDES.includes(second)?second:'buy'):jump==='trade'?(TRADE_SIDES.includes(third)?third:'buy'):null;
 return {page,jump,trade};
}
export function routeHash({page,jump=null,trade=null}){
 if(!pageNames.has(page))throw Error('Unknown workspace page');
 if(page==='trade')return '#trade/'+(TRADE_SIDES.includes(trade)?trade:'buy');
 if(page==='overview'&&homeTargets.has(jump))return '#overview/'+jump+(jump==='trade'?'/'+(TRADE_SIDES.includes(trade)?trade:'buy'):'');
 return '#'+page;
}
export function visibleWorkspaceSections(surface,page){
 return surface==='member'&&page==='overview'?[...HOME_SECTIONS]:[page];
}
export function selectTradeSide(side){
 if(!TRADE_SIDES.includes(side))return;
 const current=parseWorkspaceRoute(location.hash);
 const next=current.page==='overview'?{page:'overview',jump:'trade',trade:side}:{page:'trade',trade:side};
 const hash=routeHash(next);if(location.hash!==hash)history.pushState(null,'',hash);
 window.dispatchEvent(new CustomEvent('fti:exchange-tab',{detail:{side}}));
}
export function initWorkspaceNavigation({surface,pages,defaultPage,pagePath,title=x=>x}){
 const labels=Object.fromEntries(pages),known=new Set(pages.map(([id])=>id));
 const reduced=()=>globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
 function apply(hash,focus=false){
  const route=parseWorkspaceRoute(hash,defaultPage);
  if(!known.has(route.page)){
   // Cross-surface links are navigation, not a second wallet connection button.
   const target=pagePath(route.page);
   if(target){const url=new URL(target,location.href);url.hash=routeHash(route);url.searchParams.set('lang',document.documentElement.lang||'fa');location.assign(url.href);}
   return;
  }
  const visible=new Set(visibleWorkspaceSections(surface,route.page));
  document.body.dataset.workspacePage=route.page;
  document.querySelectorAll('.page').forEach(el=>{el.hidden=!visible.has(el.id);});
  document.querySelectorAll('[data-page]').forEach(el=>{
   const active=el.dataset.page===route.page;el.classList.toggle('active',active);
   if(active)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');
  });
  const heading=document.getElementById('page-title');
  if(heading)heading.textContent=title(labels[route.page]);
  document.title=title(labels[route.page])+' · FTI Protocol';
  if(route.trade)window.dispatchEvent(new CustomEvent('fti:exchange-tab',{detail:{side:route.trade}}));
  window.dispatchEvent(new CustomEvent('fti:pagechange',{detail:route}));
  if(focus||route.jump){
   requestAnimationFrame(()=>{
    const target=document.getElementById(route.jump||'page-title');
    if(!target)return;
    target.focus({preventScroll:true});target.scrollIntoView({block:'start',behavior:reduced()?'instant':'smooth'});
   });
  }
  if(route.page==='network'&&new URLSearchParams(location.search).get('view')==='tree'){
   requestAnimationFrame(()=>document.getElementById('network-explorer')?.scrollIntoView({block:'start',behavior:reduced()?'instant':'smooth'}));
  }
 }
 function click(event){
  const el=event.target.closest?.('[data-page],[data-go],[data-jump]');
  if(!el||el.disabled||event.defaultPrevented||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
  event.preventDefault();
  const route=el.dataset.jump?{page:'overview',jump:el.dataset.jump,trade:el.dataset.trade}:parseWorkspaceRoute(el.dataset.page||el.dataset.go,defaultPage);
  const hash=routeHash(route);if(location.hash!==hash)history.pushState(null,'',hash);
  apply(hash,true);
 }
 const changed=()=>apply(location.hash);
 document.addEventListener('click',click);
 window.addEventListener('hashchange',changed);
 window.addEventListener('fti:refresh-navigation',changed);
 apply(location.hash);
 return ()=>{document.removeEventListener('click',click);window.removeEventListener('hashchange',changed);window.removeEventListener('fti:refresh-navigation',changed);};
}
