import React,{useState} from 'react';
import {shareLinks,sharedWebsite} from './social-share.js';
import {t,language,LANGUAGES,changeLanguage} from './locale.js';
import socialConfig from '../config/social-links.json';
import {validatedSocialLinks} from './social-policy.js';
export function LanguageSelect({id='language-select',className=''}){
 return <label className={'fti-language '+className}><span>{t('Language')}</span>
  <select id={id} aria-label={t('Choose language')} value={language} onChange={e=>{if(!e.target.disabled)changeLanguage(e.target.value);}}>
   {LANGUAGES.map(l=><option key={l.code} value={l.code} lang={l.code} dir={l.dir}>{l.label}</option>)}
  </select></label>;
}
export function SocialLinks(){
 const links=validatedSocialLinks(socialConfig),sharing=shareLinks(language);
 const [copyState,setCopyState]=useState('idle');
 async function copy(){try{await navigator.clipboard.writeText(sharedWebsite(language));setCopyState('copied');}catch{setCopyState('manual');}}
 return <section className="fti-social" aria-label={t('Share FTI')}>
  <div className="social-block"><h2>{t('Share FTI')}</h2>
   <nav aria-label={t('Share FTI')}>{sharing.map(l=><a key={l.id} href={l.href} target="_blank" rel="noopener noreferrer" className="social-action" data-social-share={l.id}><SocialIcon name={l.id}/>{t(l.label)}<span aria-hidden="true"> ↗</span></a>)}
    <button type="button" className="secondary social-action" onClick={copy}><SocialIcon name="link"/>{t('Copy website link')}</button>
   </nav><p>{t('Sharing opens a draft. Nothing is posted automatically.')}</p>
   <p role="status">{copyState==='copied'?t('Website link copied.'):copyState==='manual'?t('Copy this link manually.'):''}</p>
   {copyState==='manual'&&<input aria-label={t('Copy website link')} value={sharedWebsite(language)} readOnly onFocus={e=>e.target.select()}/>}
  </div>
  <div className="social-block"><h2>{t('Verified project links')}</h2>
   <nav aria-label={t('Official social channels')}>{links.map(l=><a key={l.id} href={l.href} target="_blank" rel="noopener noreferrer" className="social-action"><SocialIcon name={l.id}/>{l.name}<span aria-hidden="true"> ↗</span></a>)}</nav>
   {links.every(l=>l.id==='github')&&<p>{t('More official channels will appear after their addresses are confirmed.')}</p>}
  </div>
 </section>;
}
function SocialIcon({name}){
 const paths={telegram:'M21 3 3 10l7 3 3 7 8-17ZM10 13l11-10',x:'M4 4l16 16M20 4 4 20',github:'M8 20v-3c-4 1-4-2-5-2M16 20v-4c0-1-.5-2-1-2 4 0 6-2 6-5 0-1-1-2-1-3 0-1 0-2-1-3-2 0-3 1-3 1-3-1-5-1-8 0 0 0-1-1-3-1-1 1-1 2-1 3 0 1-1 2-1 3 0 3 2 5 6 5-.5 0-1 1-1 2v4',link:'M10 14 14 10M8 16l-1 1a4 4 0 0 1-6-6l4-4a4 4 0 0 1 6 0M16 8l1-1a4 4 0 0 1 6 6l-4 4a4 4 0 0 1-6 0'};
 return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]||'M5 12h14m-6-6 6 6-6 6'}/></svg>;
}
export function TranslationNotice({includePersian=false}){
 if(language==='en'||language==='fa'&&!includePersian)return null;
 return <p className="fti-translation-notice" role="note">{t('Core controls are translated. Some detailed explanations are still shown in English.')}</p>;
}
