import React,{useEffect,useState} from 'react';
import {t} from './locale.js';
import {TRADE_SIDES,parseWorkspaceRoute,selectTradeSide} from './workspace-navigation.js';

// All three panels stay mounted. Switching tabs neither clears draft amounts nor
// creates extra form IDs. The existing controller keeps sole signing authority.
export function TradeCenter({buy,sell,transfer}){
 const [side,setSide]=useState(()=>parseWorkspaceRoute(location.hash).trade||'buy');
 useEffect(()=>{
  const changed=e=>{if(TRADE_SIDES.includes(e.detail?.side))setSide(e.detail.side);};
  window.addEventListener('fti:exchange-tab',changed);
  return ()=>window.removeEventListener('fti:exchange-tab',changed);
 },[]);
 function choose(next){setSide(next);selectTradeSide(next);}
 function key(event){
  if(event.currentTarget.disabled)return;
  const index=TRADE_SIDES.indexOf(side),rtl=document.documentElement.dir==='rtl';
  let next;
  if(event.key==='Home')next=0;
  else if(event.key==='End')next=2;
  else if(event.key==='ArrowRight')next=(index+(rtl?2:1))%3;
  else if(event.key==='ArrowLeft')next=(index+(rtl?1:2))%3;
  else return;
  event.preventDefault();choose(TRADE_SIDES[next]);
  document.getElementById('exchange-tab-'+TRADE_SIDES[next])?.focus();
 }
 const panels={buy,sell,transfer},labels={buy:'Buy FTI',sell:'Sell FTI',transfer:'Transfer FTI'};
 return <div className="trade-center exchange-orders" data-active-trade={side}>
  <div className="trade-tabs" role="tablist" aria-label={t('Buy, sell & transfer')}>
   {TRADE_SIDES.map(mode=><button key={mode} type="button" role="tab" id={'exchange-tab-'+mode}
    data-exchange-tab={mode} aria-controls={'exchange-panel-'+mode} aria-selected={side===mode}
    tabIndex={side===mode?0:-1} onKeyDown={key} onClick={e=>{if(!e.currentTarget.disabled)choose(mode);}}>{t(labels[mode])}</button>)}
  </div>
  {TRADE_SIDES.map(mode=><div key={mode} id={'exchange-panel-'+mode} role="tabpanel"
   aria-labelledby={'exchange-tab-'+mode} hidden={side!==mode} tabIndex="0">{panels[mode]}</div>)}
 </div>;
}
