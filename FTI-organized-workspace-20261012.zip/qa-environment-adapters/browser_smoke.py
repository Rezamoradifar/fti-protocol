import json,re,pathlib,urllib.request,time,base64
from playwright.sync_api import sync_playwright
W=pathlib.Path('/mnt/data/fti-ui-work');root=W/'source'
ready=re.search(r'FTI_QA_READY (.+)',(W/'browser-server.log').read_text())
assert ready,'fixture not ready'
info=json.loads(ready.group(1));base=info['url']
client=urllib.request.build_opener(urllib.request.ProxyHandler({}))
requests=[]
def http(arg):
    url=arg['url']
    assert url.startswith(base+'/'),'External requests are blocked: '+url
    body=arg.get('body');method=arg.get('method','GET')
    headers={'Content-Type':'application/json'} if method=='POST' else {}
    req=urllib.request.Request(url,data=body.encode() if isinstance(body,str) else None,method=method,headers=headers)
    try:
        with client.open(req,timeout=25) as r:
            content=r.read(8_000_000);status=r.status;ct=r.headers.get('Content-Type','application/json')
    except urllib.error.HTTPError as e:content=e.read();status=e.code;ct='application/json'
    requests.append({'url':url.split('?')[0],'method':method})
    return {'body':content.decode('utf8'),'status':status,'headers':{'Content-Type':ct}}
js=(W/'browser-fixture.js').read_text()
css='\n'.join((root/'web'/p).read_text() for p in ['style.css','member-landing-theme.css','global-interface.css'])
setup=r'''({url,theme})=>{
 let current=new URL(url);const stack=[url];let cursor=0;
 globalThis.__testLocation={get href(){return current.href},get origin(){return current.origin},get pathname(){return current.pathname},get search(){return current.search},get hash(){return current.hash},assign(v){current=new URL(v,current);window.dispatchEvent(new Event('hashchange'));},reload(){}};
 globalThis.__testHistory={pushState(s,t,v){current=new URL(v,current);stack.splice(++cursor);stack[cursor]=current.href;},replaceState(s,t,v){current=new URL(v,current);stack[cursor]=current.href;},back(){if(cursor){current=new URL(stack[--cursor]);window.dispatchEvent(new Event('hashchange'));}}};
 const storage=new Map([['fti-theme',theme]]), session=new Map();
 const adapter=m=>({getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k)});
 Object.defineProperty(globalThis,'localStorage',{value:adapter(storage),configurable:true});
 Object.defineProperty(globalThis,'sessionStorage',{value:adapter(session),configurable:true});
 Object.defineProperty(navigator,'clipboard',{value:{writeText:async t=>{globalThis.__copied=t}},configurable:true});
 globalThis.fetch=async(input,init={})=>{
  const u=new URL(typeof input==='string'?input:input.url,current);
  const body=init.body instanceof Uint8Array?new TextDecoder().decode(init.body):init.body;
  const r=await __ftiHttp({url:u.href,body:body??null,method:init.method||'GET'});
  return new Response(r.body,{status:r.status,headers:r.headers});
 };
}'''
report={'scope':'LOCAL_BROWSER_CONTROLLER_AND_GANACHE_WITH_ORIGIN_HTTP_ADAPTER','productionURLNavigationBlocked':True,'controllerStubbed':False,'publicChainTransactions':False,'checks':[]}
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':390,'height':850},reduced_motion='reduce')
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('console',lambda m:print('BROWSER',m.type,m.text[:150]) if m.type=='error' else None)
    page.expose_function('__ftiHttp',http)
    page.set_content('<!doctype html><html><head><meta charset="utf-8"><style>'+css+'</style></head><body><div id="root"></div></body></html>')
    page.evaluate(setup,{'url':base+'/app/?lang=fa','theme':'dark'})
    page.add_script_tag(type='module',content=js)
    page.wait_for_selector('#connect',timeout=10000)
    page.wait_for_function("document.querySelector('#connect-label').textContent.startsWith('0x')",timeout=30000)
    page.wait_for_function("document.querySelector('#fti-balance').textContent !== '—'",timeout=15000)
    print('STATUS',page.locator('#status').inner_text())
    print('PAGE ERRORS',errors)
    assert not errors,errors
    visible=page.evaluate("[...document.querySelectorAll('.page')].filter(el=>!el.hidden).map(el=>el.id)")
    assert visible==['overview','trade','rewards','network'],visible
    report['checks'].append('home: four sections visible, one instance per form')
    assert page.locator('#connect').count()==1
    assert page.locator('#language-select option').last.get_attribute('value')=='fa'
    assert page.locator('form#buy-form').count()==page.locator('form#sell-form').count()==page.locator('form#transfer-form').count()==1
    ids=page.evaluate("[...document.querySelectorAll('[id]')].map(el=>el.id)")
    assert len(ids)==len(set(ids)),[x for x in ids if ids.count(x)>1]
    report['checks'].append('single wallet entry and unique live DOM IDs; Persian last')
    page.locator('#buy-form input[name="amount"]').fill('12.5')
    page.locator('#exchange-tab-sell').click();page.locator('#sell-form input[name="amount"]').fill('2.5')
    page.locator('#exchange-tab-transfer').click()
    assert page.locator('#transfer-form').is_visible()
    assert not page.locator('#buy-form').is_visible()
    page.locator('#transfer-form input[name="to"]').fill(info['accounts'][1]);page.locator('#transfer-form input[name="amount"]').fill('1')
    page.locator('#exchange-tab-buy').click();assert page.locator('#buy-form input[name="amount"]').input_value()=='12.5'
    page.locator('#exchange-tab-sell').click();assert page.locator('#sell-form input[name="amount"]').input_value()=='2.5'
    page.locator('#exchange-tab-sell').press('End');assert page.locator('#exchange-tab-transfer').get_attribute('aria-selected')=='true'
    page.locator('#exchange-tab-transfer').press('Home');assert page.locator('#exchange-tab-buy').get_attribute('aria-selected')=='true'
    report['checks'].append('buy/sell/transfer tabs retain drafts and keyboard navigation works')
    page.locator('[data-page="trade"]').click()
    assert page.evaluate("[...document.querySelectorAll('.page')].filter(el=>!el.hidden).map(el=>el.id)")==['trade']
    page.locator('[data-page="overview"]').click();page.locator('[data-jump="auto-preferences"]').click()
    assert page.locator('#auto-preferences').is_visible()
    page.locator('[data-jump="trade"][data-trade="transfer"]').click();page.locator('#transfer-form').wait_for(state='visible')
    report['checks'].append('sidebar and homepage jump links work without switching domains')
    page.wait_for_selector('.price-line',timeout=30000)
    assert 'C' in page.locator('#trade .price-line').get_attribute('d')
    assert page.locator('#trade .price-area').count()==1
    report['checks'].append('curve drawn from actual local-contract historical prices')
    assert page.locator('[data-social-share="telegram"]').get_attribute('href').startswith('https://t.me/share/url?')
    assert page.locator('[data-social-share="x"]').get_attribute('href').startswith('https://twitter.com/intent/tweet?')
    page.locator('.fti-social button').click();assert page.evaluate('globalThis.__copied').startswith('https://ftiprotocol.com/')
    report['checks'].append('social share destinations and copy button work; no posts sent')
    # No external wallet: local-mode controller uses Ganache unlocked fixture accounts.
    page.locator('[data-jump="trade"][data-trade="buy"]').click();page.locator('#buy-form input[name="amount"]').fill('1')
    page.wait_for_function("!document.querySelector('#buy-form [data-write]').disabled")
    before=page.locator('#fti-balance').inner_text();page.locator('#buy-form [data-write]').click()
    page.wait_for_function("previous=>document.querySelector('#fti-balance').textContent !== previous",arg=before,timeout=20000)
    page.wait_for_function("!document.querySelector('#connect').disabled",timeout=20000)
    report['checks'].append('real buy form executes on the isolated local EVM')
    page.locator('#exchange-tab-sell').click();page.locator('#sell-form input[name="amount"]').fill('1')
    before=page.locator('#fti-balance').inner_text();page.locator('#sell-form [data-write]').click()
    page.wait_for_function("previous=>document.querySelector('#fti-balance').textContent !== previous",arg=before,timeout=20000)
    page.wait_for_function("!document.querySelector('#connect').disabled",timeout=20000)
    report['checks'].append('real sell form executes on the isolated local EVM')
    page.locator('#exchange-tab-transfer').click();page.locator('#transfer-form input[name="to"]').fill(info['accounts'][1]);page.locator('#transfer-form input[name="amount"]').fill('1')
    before=page.locator('#fti-balance').inner_text();page.locator('#transfer-form [data-write]').click()
    page.wait_for_function("previous=>document.querySelector('#fti-balance').textContent !== previous",arg=before,timeout=20000)
    page.wait_for_function("!document.querySelector('#connect').disabled",timeout=20000)
    report['checks'].append('real transfer form executes on isolated local EVM; same guarded handler')
    # Screenshot only after local-scope label is inserted by QA, never in product.
    page.locator('[data-page="overview"]').click();page.locator('[data-jump="trade"][data-trade="buy"]').click();page.evaluate('window.scrollTo(0,0)')
    page.evaluate("""()=>{const el=document.createElement('div');el.textContent='LOCAL TEST · SAMPLE DATA · NOT THE LIVE SITE';el.style.cssText='position:fixed;bottom:0;left:0;right:0;z-index:9999;background:#102019;color:#eaf1ed;text-align:center;font:10px/24px sans-serif';document.body.append(el)}""")
    page.screenshot(path=str(W/'FTI-organized-home-mobile.png'),full_page=True)
    for width in [320,390,768,1440]:
        page.set_viewport_size({'width':width,'height':900});page.wait_for_timeout(100)
        dims=page.evaluate('({scroll:document.documentElement.scrollWidth,width:innerWidth})')
        assert dims['scroll']<=dims['width']+1,dims
    page.set_viewport_size({'width':1440,'height':1050});page.evaluate('window.scrollTo(0,0)');page.screenshot(path=str(W/'FTI-organized-home-desktop.png'),full_page=True)
    report['checks'].append('RTL viewports 320/390/768/1440 without page overflow')
    assert not errors,errors
    report['httpRequestCount']=len(requests);report['result']='PASS';report['errors']=errors
    (W/'browser-results.json').write_text(json.dumps(report,indent=2))
    browser.close()
print(json.dumps(report,indent=2))
