import {build} from './source/node_modules/esbuild/lib/main.js';
import path from 'node:path';
const root=path.resolve('/mnt/data/fti-ui-work/source');
// Browser URL navigation is prohibited in this environment. Only origin/history
// and HTTP transport are adapted. The production controller and ethers run intact.
await build({absWorkingDir:root,entryPoints:['frontend/main.jsx'],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:'/mnt/data/fti-ui-work/browser-fixture.js',external:['/vendor/walletconnect.js'],plugins:[{name:'local-ethers',setup(b){b.onResolve({filter:/^\/vendor\/ethers\.js$/},()=>({path:path.join(root,'node_modules/ethers/dist/ethers.js')}));}}],define:{'process.env.NODE_ENV':'"production"','location':'globalThis.__testLocation','globalThis.location':'globalThis.__testLocation','window.location':'globalThis.__testLocation','history':'globalThis.__testHistory'},minify:true});
