# Origin/HTTP adapter only; execute the actual production controller with a local EVM.
import json,re,pathlib,urllib.request,time
from playwright.sync_api import sync_playwright
source=pathlib.Path('/mnt/data/fti-ui-work/browser_smoke.py').read_text()
exec(source[:source.index('report={')])
results=[];errors=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for surface,lang in [('app',lang) for lang in ['en','ar','tr','zh-CN','ru','es','fa']]+[(surface,lang) for surface in ['token','admin'] for lang in ['en','fa']]:
  page=browser.new_page(viewport={'width':390,'height':900},reduced_motion='reduce')
  page.on('pageerror',lambda e:errors.append(str(e)));page.expose_function('__ftiHttp',http)
  page.set_content('<html><head><meta charset="utf-8"><style>'+css+'</style></head><body><div id="root"></div></body></html>')
  page.evaluate(setup,{'url':base+'/'+surface+'/?lang='+lang,'theme':'dark'})
  page.add_script_tag(type='module',content=js)
  page.wait_for_function("document.querySelector('#connect-label')?.textContent.startsWith('0x')",timeout=30000)
  page.wait_for_function("!document.querySelector('#connect').disabled",timeout=30000)
  assert page.locator('#language-select option').last.get_attribute('value')=='fa'
  assert page.locator('#language-select').input_value()==lang
  assert page.locator('html').get_attribute('dir')==('rtl' if lang in ['ar','fa'] else 'ltr')
  for theme in ['dark','light']:
   if theme=='light':page.locator('#theme').click()
   for width in [390,1440]:
    page.set_viewport_size({'width':width,'height':1000});page.wait_for_timeout(120)
    dims=page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})')
    assert dims['scroll']<=dims['width']+1,{'lang':lang,'theme':theme,**dims}
    assert page.locator('#connect').count()==1
    if surface!='admin':
     if surface=='token':page.locator('[data-page="trade"]').click()
     page.locator('#exchange-tab-transfer').click();page.locator('#transfer-form').wait_for(state='visible')
     assert not page.locator('#buy-form').is_visible()
     page.locator('#exchange-tab-buy').click();page.locator('#buy-form').wait_for(state='visible')
     pairs=page.locator('[data-exchange-tab]').evaluate_all("els=>els.map(el=>({fg:getComputedStyle(el).color,bg:getComputedStyle(el).backgroundColor}))")
     def lum(c):
      vals=[int(n)/255 for n in re.findall(r'\d+',c)[:3]];v=[x/12.92 if x<=.04045 else ((x+.055)/1.055)**2.4 for x in vals];return .2126*v[0]+.7152*v[1]+.0722*v[2]
     for pair in pairs:
      a,b=sorted([lum(pair['fg']),lum(pair['bg'])]);assert (b+.05)/(a+.05)>=4.5,{'surface':surface,'lang':lang,'theme':theme,'pair':pair}

    results.append({'surface':surface,'language':lang,'theme':theme,'width':width,'status':'PASS'})
  page.close()
 browser.close()
assert not errors,errors
report={'result':'PASS','scope':'LOCAL_CONTROLLER_ORIGIN_HTTP_ADAPTER','combinations':len(results),'rows':results,'javascriptErrors':errors,'walletProvider':'Ganache local unlocked accounts; not a mobile-wallet extension'}
(W/'browser-matrix.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
